package com.test.repository;

import org.springframework.data.repository.CrudRepository;

import com.test.beans.PaymentMethod;

public interface PaymentRepository extends CrudRepository<PaymentMethod,String>{

}
