package com.test.repository;

import org.springframework.data.repository.CrudRepository;

import com.test.beans.ReturnLinks;

public interface ReturnLinksRepository extends CrudRepository<ReturnLinks,String> {

}
